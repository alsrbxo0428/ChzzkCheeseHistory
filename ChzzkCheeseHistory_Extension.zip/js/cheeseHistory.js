window.CCH = {
    channels: [],
    channel: null,
    date: new Date(),
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    monthArr: Array.from({length: 12}, (_, i) => i + 1),
    yearArr: Array.from({length: new Date().getFullYear() - 2023 + 1}, (_, i) => 2023 + i),
    selectboxState: {}
};

function initCheeseHistory() {
    document.body.style.overflow = "hidden";
    document.getElementById("closeModalBtn").addEventListener("click", () => {
        closeCheeseHistoryModal();
    });

    document.getElementById("cheeseHistoryModal").addEventListener("click", (e) => {
        if(e.target.id === "cheeseHistoryModal") {
            closeCheeseHistoryModal();
        }
    });

    document.addEventListener("keydown", (e) => {
        if(e.key === "Escape") {
            closeCheeseHistoryModal();
        }
    });

    chgCalendarYear(CCH.year);
    chgCalendarMonth(CCH.month);
    
    document.querySelectorAll(".cch_selectbox_component").forEach((element) => {
        const key = element.dataset.key;
        CCH.selectboxState[key] = false;
        element.addEventListener("focus", handleFocusChange);
        element.addEventListener("blur", handleFocusChange);
    });

    let year_selectbox_items = ``;
        for(let year of CCH.yearArr) {
            year_selectbox_items += `<li class="cch_selectbox_item">
                <button type="button" class="cch_selectbox_option" onclick="chgCalendarYear(${year});">${year}년</button>
            </li>`;
        }
        document.querySelector(".calendar_year_selectbox").innerHTML = year_selectbox_items;

    let month_selectbox_items = ``;
    for(let month of CCH.monthArr) {
        month_selectbox_items += `<li class="cch_selectbox_item">
            <button type="button" class="cch_selectbox_option" onclick="chgCalendarMonth(${month});">${month}월</button>
        </li>`;
    }
    document.querySelector(".calendar_month_selectbox").innerHTML = month_selectbox_items;

    initApi();
};

function handleFocusChange(event) {
    const element = event.target;
    const key = element.dataset.key;

    if(!key) return;

    if(event.type === "focus") {
        element.classList.add("cch_selectbox_is_focused");
        document.querySelector(`.${key}_selectbox`).dataset.visible = "block";
    } else if(event.type === "blur") {
        element.classList.remove("cch_selectbox_is_focused");
        setTimeout(function() {
            document.querySelector(`.${key}_selectbox`).dataset.visible = "none";
        }, 100);
    }
}

function chgCalendarYear(yearParam) {
    document.getElementsByClassName("cch_selectbox_inner")[0].innerHTML = `${yearParam}년` + returnSelectboxIconArrow();
    CCH.year = yearParam;
}

function chgCalendarMonth(monthParam) {
    document.getElementsByClassName("cch_selectbox_inner")[1].innerHTML = `${monthParam}월` + returnSelectboxIconArrow();
    CCH.month = monthParam;
}

function changeSortType() {
    document.getElementById("channelListContainer").innerHTML = makeList(CCH.channels);
}

function chgView(type) {
    if(CCH.channel == null) {
        alert("조회할 채널을 선택해주세요.");
        return;
    }

    if(type === 'Channel') {
        moveChannelView(true);
        moveGraphView(false);
        moveCalendarView(false);
    } else if(type === 'Graph') {
        moveChannelView(false);
        moveGraphView(true);
        moveCalendarView(false);
    } else if(type === 'Calendar') {
        moveChannelView(false);
        moveGraphView(false);
        moveCalendarView(true);
    }
}

function moveChannelView(flag) {
    if(flag) {
        document.getElementById("channelBtn").classList.add("on");
        document.getElementById("cch_channelList").dataset.visible = "block";
        document.getElementById("totalContainer").dataset.visible = "flex";
    } else {
        document.getElementById("channelBtn").classList.remove("on");
        document.getElementById("cch_channelList").dataset.visible = "none";
        document.getElementById("totalContainer").dataset.visible = "none";
    }
}

function moveGraphView(flag) {
    if(flag) {
        document.getElementById("graphBtn").classList.add("on");
        document.getElementById("channelHistory").dataset.visible = "block";
    } else {
        document.getElementById("graphBtn").classList.remove("on");
        document.getElementById("channelHistory").dataset.visible = "none";
    }
}

function moveCalendarView(flag) {
    if(flag) {
        document.getElementById("calendarBtn").classList.add("on");
        document.getElementById("channelHistoryCalendar").dataset.visible = "block";
        document.querySelector(".cch_selectbox").dataset.visible = "block";
    } else {
        document.getElementById("calendarBtn").classList.remove("on");
        document.getElementById("channelHistoryCalendar").dataset.visible = "none";
        document.querySelector(".cch_selectbox").dataset.visible = "none";
    }
}

function chgCalendarDate(yearParam, monthParam, focusDay) {
    CCH.year = yearParam;
    CCH.month = monthParam;
    
    document.getElementsByClassName("cch_selectbox_inner")[0].innerHTML = `${CCH.year}년` + returnSelectboxIconArrow();
    document.getElementsByClassName("cch_selectbox_inner")[1].innerHTML = `${CCH.month}월` + returnSelectboxIconArrow();
    rendarCalendar(focusDay);
}

function goPrev() {
    CCH.month--;
    if(CCH.month <= 0) CCH.month = 12, CCH.year -= 1;

    chgCalendarDate(CCH.year, CCH.month, null);
}

function goNext() {
    CCH.month++;
    if(CCH.month > 12) CCH.month = 1, CCH.year++;

    chgCalendarDate(CCH.year, CCH.month, null);
}

function goDate(date) {
    let splitedDate = date.split('-');

    chgCalendarDate(Number(splitedDate[0]), Number(splitedDate[1]), Number(splitedDate[2]));
}

function goToday() {
    let today = new Date();
    CCH.year = today.getFullYear();
    CCH.month = today.getMonth() + 1;

    chgCalendarDate(CCH.year, CCH.month, null);
}

async function initApi() {
    const cheeseDataArr = await getCheeseHistoryJson();
    
    CCH.channels = [];
    
    convertCheeseDataArrToChannelData(cheeseDataArr);

    initializationHtml();
}

async function getCheeseHistoryJson() {
    const result = [];
    
    for(const year of CCH.yearArr) {
        try {
            const res = await fetch(
                `https://api.chzzk.naver.com/commercial/v1/product/purchase/history?page=0&size=50000&searchYear=${year}`,
                {
                    headers: {
                        "accept": "application/json, text/plain, */*",
                        "cache-control": "no-cache",
                        "pragma": "no-cache"
                    },
                    method: "GET",
                    credentials: "include"
                }
            );

            if(!res.ok) throw new Error(`HTTP ${res.status}`);

            const data = await res.json();

            if(data.code !== 200) throw new Error(data.message);

            result.push(...(data?.content?.data || []));
        } catch (error) {
            console.error(`${year}년 조회 실패`, error);
        }

        await new Promise(resolve => setTimeout(resolve, 100));
    }

    return result;
}

function convertCheeseDataArrToChannelData(cheeseDataArr) {
    if(cheeseDataArr) {
        cheeseDataArr.sort((a, b) => {
            if(a.purchaseDate < b.purchaseDate) return -1;
            if(a.purchaseDate > b.purchaseDate) return 1;
            return 0;
        });

        for(let cheeseData of cheeseDataArr) {
            if(cheeseData.donationType === "TTS") continue;

            let splitedPurchaseDate = cheeseData.purchaseDate.split(' ')[0].split('-');
            let purchaseYear = Number(splitedPurchaseDate[0]);
            let purchaseMonth = Number(splitedPurchaseDate[1]);
            let purchaseDay = Number(splitedPurchaseDate[2]);
            let payAmount = Number(cheeseData.payAmount);

            let channelData = CCH.channels.find(channel => channel.channelId === cheeseData.channelId);
            if(!channelData) {
                channelData = createNewChannelData(cheeseData);
                CCH.channels.push(channelData);
            }

            let yearData = channelData.yearData.find(data => data.year === purchaseYear);
            if(!yearData) {
                yearData = {
                    year: purchaseYear,
                    yearTotal: 0,
                    yearCount: 0,
                    monthData: []
                }
                channelData.yearData.push(yearData);
            }

            yearData.yearTotal += payAmount;
            yearData.yearCount++;
            
            let monthData = yearData.monthData.find(data => data.month === purchaseMonth);
            if(!monthData) {
                monthData = {
                    month: purchaseMonth,
                    monthTotal: 0,
                    monthCount: 0,
                    dayData: []
                }
                yearData.monthData.push(monthData);
            }

            monthData.monthTotal += payAmount;
            monthData.monthCount++;

            let dayData = monthData.dayData.find(data => data.day === purchaseDay);
            if(!dayData) {
                dayData = {
                    day: purchaseDay,
                    dayTotal: 0,
                    dayCount: 0
                }
                monthData.dayData.push(dayData);
            }

            dayData.dayTotal += payAmount;
            dayData.dayCount++;
        }
    }
}

function initializationHtml() {
    if(window.monthlyChart instanceof Chart) {
        window.monthlyChart.destroy();
    }

    rebuildChannels();

    let totalPayAmount = 0;
    for(let channel of CCH.channels) {
        totalPayAmount += channel.channelTotal;
    }

    document.getElementById("channelInfo").innerText = '';
    document.getElementById("channelInfoYear").innerText = '';
    document.getElementById("totalPayAmount").innerText = `전체 후원 금액 : ${totalPayAmount.toLocaleString("ko-KR")}원`;
    document.getElementById("channelListContainer").innerHTML = makeList(CCH.channels);
    if(CCH.channels.length > 0) {
        document.getElementById("channelListContainer").dataset.visible = "block";
    }
}

function makeList(channels) {
    let sortType = document.querySelector("input[name='sortType']:checked")?.value;
    let sortedChannels = [...channels];
    if('total' === sortType) {
        sortedChannels.sort((a, b) => b.channelTotal - a.channelTotal);
    }

    let html = `
    <div id="cch_channelList">
        ${sortedChannels.map(channel => `
            <button onclick="getChannelHistory('${channel.channelId}');">
                <span>
                    <img class="cheeseImg" 
                        ${
                            channel.cheese04 ? 'src="https://ssl.pstatic.net/static/nng/glive/badge/cheese04.png"' :
                            channel.cheese03 ? 'src="https://ssl.pstatic.net/static/nng/glive/badge/cheese03.png"' :
                            channel.cheese02 ? 'src="https://ssl.pstatic.net/static/nng/glive/badge/cheese02.png"' :
                            channel.cheese01 ? 'src="https://ssl.pstatic.net/static/nng/glive/badge/cheese01.png"' : ''
                        }
                    >
                    <img class="channelImg" src="${channel.channelImageUrl}" />
                </span>
                <p>${channel.channelName}</p>
                <p>${Number(channel.channelTotal).toLocaleString("ko-KR")}원</p>
            </button>
        `).join('')}
    </div>`;

    return html;
}

function getChannelHistory(channelId) {
    let channelInfoYear = '';
    CCH.channel = CCH.channels.find(channel => channel.channelId === channelId);
    
    document.getElementById("channelHistoryWrap").dataset.visible = "block";
    document.getElementById("channelInfo").innerText = `${CCH.channel.channelName} 총 후원 금액 : ${Number(CCH.channel.channelTotal).toLocaleString("ko-KR")}원 (${CCH.channel.channelCount.toLocaleString("ko-KR")}회)`;

    if(CCH.channel.yearData.length > 0) {
        let yearIdx = -1;
        for(let year of CCH.yearArr) {
            yearIdx = CCH.channel.yearData.findIndex(data => data.year === year);
            if(yearIdx !== -1) {
                channelInfoYear += `<li>${CCH.channel.yearData[yearIdx].year}년 : ${Number(CCH.channel.yearData[yearIdx].yearTotal).toLocaleString("ko-KR")}원 (${CCH.channel.yearData[yearIdx].yearCount.toLocaleString("ko-KR")}회)</li>`;
                yearIdx = -1;
            }
        }
    }
    document.getElementById("channelInfoYear").innerHTML = channelInfoYear;
    
    renderMonthlyChart();
    rendarCalendar();
    chgView('Graph');
}

function renderMonthlyChart() {
    const ctx = document.getElementById('monthlyChart').getContext('2d');

    if (window.monthlyChart instanceof Chart) {
        window.monthlyChart.destroy();
    }

    window.monthlyChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
            datasets: makeChartDatasets()
        },
        options: {
            plugins: {
                tooltip: {
                    callbacks: {
                        title: function(tooltipItems) {
                            return `${tooltipItems[0].dataset.label} ${tooltipItems[0].label}`;
                        },
                        label: function(tooltipItem) {
                            return `후원 금액: ${tooltipItem.formattedValue}원`;
                        },
                        footer: function(tooltipItem) {
                            let year = Number(tooltipItem[0].dataset.label.replace(/[^0-9]/g, ''));
                            let yearData = CCH.channel.yearData.find(data => data.year === year);
                            let dataIdx = tooltipItem[0].dataIndex;
                            let monthCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

                            if(yearData) {
                                let monthData = null;
                                for(let month of CCH.monthArr) {
                                    monthData = yearData.monthData.find(data => data.month === month);
                                    if(monthData) {
                                        monthCount[month - 1] = monthData.monthCount;
                                    }
                                }
                            }

                            return `후원 횟수: ${monthCount[dataIdx].toLocaleString("ko-KR")}회`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    title: {
                        display: true
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: '후원 금액 (원)'
                    }
                }
            }
        }
    });
}

function makeChartDatasets() {
    let datasets = [];
    let yearIdx = -1;
    let yearData = null;
    let monthIdx = -1;
    let monthTotal = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    for(let year of CCH.yearArr) {
        yearIdx = CCH.channel.yearData.findIndex(data => data.year === year);
        if(yearIdx !== -1) {
            yearData = CCH.channel.yearData[yearIdx];

            for(let month of CCH.monthArr) {
                monthIdx = yearData.monthData.findIndex(data => data.month === month);
                if(monthIdx !== -1) {
                    monthTotal[month - 1] = yearData.monthData[monthIdx].monthTotal;
                }
            }

            datasets.push({
                label: `${CCH.channel.yearData[yearIdx].year}년`,
                data: monthTotal
            });
            
            yearIdx = -1;
            yearData = null;
            monthIdx = -1;
            monthTotal = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        }
    }

    return datasets;
}

function rendarCalendar(focusDay) {
    let yearData = null;
    let monthData = null;
    let dayData = null;

    if(CCH.channel) {
        yearData = CCH.channel.yearData.find(data => data.year === CCH.year);
        monthData = yearData ? yearData.monthData.find(data => data.month === CCH.month) : null;

        document.getElementsByClassName("calendar_month_total")[0].innerHTML = monthData ? (`<h3>${CCH.month}월 후원 금액 : ${Number(monthData.monthTotal).toLocaleString("ko-KR")}원 (${monthData.monthCount.toLocaleString("ko-KR")}회)</h3>`) : `<h3>${CCH.month}월 후원 금액: 0원 (0회)</h3>`;
        document.getElementsByClassName("cheese_history")[0].innerHTML = `
        <ul>
            <li><button onclick="goToday();"><h4>TODAY</h4></button></li>
            ${CCH.channel.onedayMaxCheese > 0 ? `<li><button onclick="goDate('${CCH.channel.onedayMaxCheeseDate}');"><h4>최고후원금액 : ${Number(CCH.channel.onedayMaxCheese).toLocaleString("ko-KR")}원</h4></button></li>` : ''}
            ${CCH.channel.cheese01 ? `<li><button onclick="goDate('${CCH.channel.cheeseDate01}');"><img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese01.png" class="cheese_history_button"></button></li>` : ''}
            ${CCH.channel.cheese02 ? `<li><button onclick="goDate('${CCH.channel.cheeseDate02}');"><img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese02.png" class="cheese_history_button"></button></li>` : ''}
            ${CCH.channel.cheese03 ? `<li><button onclick="goDate('${CCH.channel.cheeseDate03}');"><img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese03.png" class="cheese_history_button"></button></li>` : ''}
            ${CCH.channel.cheese04 ? `<li><button onclick="goDate('${CCH.channel.cheeseDate04}');"><img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese04.png" class="cheese_history_button"></button></li>` : ''}
        </ul>`;
    }
    
    document.getElementsByClassName("calendarDate")[0].innerText = `${CCH.year}년 ${CCH.month}월`;

    const prevLast = new Date(CCH.year, CCH.month - 1, 0);
    const thisLast = new Date(CCH.year, CCH.month, 0);

    const PLDate = prevLast.getDate();
    const PLDay = prevLast.getDay();

    const TLDate = thisLast.getDate();
    const TLDay = thisLast.getDay();

    const prevDates = [];
    const thisDates = [...Array(TLDate + 1).keys()].slice(1);
    const nextDates = [];

    if(PLDay !== 6) {
        for(let i = 0; i < PLDay + 1; i++) {
            prevDates.unshift(PLDate - i);
        }
    }

    for(let i = 1; i < 7 - TLDay; i++) {
        nextDates.push(i);
    }

    const dates = prevDates.concat(thisDates, nextDates);

    const firstDateIndex = dates.indexOf(1);
    const lastDateIndex = dates.lastIndexOf(TLDate);

    dates.forEach((date, i) => {
        const condition = i >= firstDateIndex && i < lastDateIndex + 1 ? 'this' : 'other';
        
        if(i % 7 === 0) dates[i] = `<tr><td class="date">`;
        else dates[i] = `<td class="date">`;

        dates[i] += `
        <span class="${condition}">
            <h4>${date} 
                    ${i >= firstDateIndex && i < lastDateIndex + 1 && CCH.channel ? `<span class="cheeseDate_span">
                        ${CCH.channel.firstCheeseDate === makeDate(CCH.year, CCH.month, date) ? '<img src="https://ssl.pstatic.net/static/nng/glive/badge/fan_03.png" class="cheeseDate">' : ''}
                        ${CCH.channel.cheese01 && CCH.channel.cheeseDate01 === makeDate(CCH.year, CCH.month, date) ? '<img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese01.png" class="cheeseDate">' : ''}
                        ${CCH.channel.cheese02 && CCH.channel.cheeseDate02 === makeDate(CCH.year, CCH.month, date) ? '<img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese02.png" class="cheeseDate">' : ''}
                        ${CCH.channel.cheese03 && CCH.channel.cheeseDate03 === makeDate(CCH.year, CCH.month, date) ? '<img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese03.png" class="cheeseDate">' : ''}
                        ${CCH.channel.cheese04 && CCH.channel.cheeseDate04 === makeDate(CCH.year, CCH.month, date) ? '<img src="https://ssl.pstatic.net/static/nng/glive/badge/cheese04.png" class="cheeseDate">' : ''}
                    </span>` : ''}
                </h4>
        </span>`;

        dates[i] += `<div class="date_inner"><ul>`;
        
        if(monthData) {
            dayData = monthData.dayData.find(data => data.day === date);
            if(i >= firstDateIndex && i < lastDateIndex + 1 && dayData) {
                dates[i] += `
                    <li>${Number(dayData.dayTotal).toLocaleString("ko-KR")}원</li>
                    <li>(${dayData.dayCount.toLocaleString("ko-KR")}회)</li>
                `;
            }

            dayData = null;
        }

        dates[i] += `</ul></div></td>`;
        
        if(i % 7 === 6) dates[i] += `</tr>`;
    });

    document.querySelector(".dates").innerHTML = dates.join('');
    
    const today = new Date();
    if(CCH.month === today.getMonth() + 1 && CCH.year === today.getFullYear()) {
        for(let date of document.querySelectorAll('.date .this')) {
            if(Number(date.innerText) === today.getDate()) {
                date.closest(".date").classList.add('today');
                break;
            }
        }
    }

    if(focusDay != null && focusDay > 0) {
        for(let date of document.querySelectorAll('.date .this')) {
            if(Number(date.innerText) === focusDay) {
                date.closest(".date").classList.add('focus_day');
                break;
            }
        }
    }
}

function makeDate(year, month, date) {
    return `${year}-${month < 10 ? '0' + month : month}-${date < 10 ? '0' + date : date}`;
}

function rebuildChannels() {
    if(CCH.channels[0] !== '') {
        CCH.channels.sort((a, b) => a.channelName.localeCompare(b.channelName));

        for(let channel of CCH.channels) {
            channel.channelTotal = 0;
            channel.channelCount = 0;
            channel.cheese01 = false;
            channel.cheeseDate01 = null;
            channel.cheese02 = false;
            channel.cheeseDate02 = null;
            channel.cheese03 = false;
            channel.cheeseDate03 = null;
            channel.cheese04 = false;
            channel.cheeseDate04 = null;
            channel.firstCheeseDate = null;
            channel.onedayMaxCheese = 0;
            channel.onedayMaxCheeseDate = null;

            channel.yearData.sort((a, b) => a.year - b.year);

            for(let year of CCH.yearArr) {
                let yearData = channel.yearData.find(data => data.year === year);

                if(yearData) {
                    for(let month of CCH.monthArr) {
                        let monthData = yearData.monthData.find(data => data.month === month);
                        
                        if(monthData && monthData.dayData) {
                            for(let dayData of monthData.dayData) {
                                channel.channelTotal += dayData.dayTotal;
                                channel.channelCount += dayData.dayCount;

                                if(!channel.firstCheeseDate) channel.firstCheeseDate = makeDate(year, month, dayData.day);
                                else if(!channel.firstCheeseDate.localeCompare(makeDate(year, month, dayData.day))) channel.firstCheeseDate = makeDate(year, month, dayData.day);
                                
                                if(!channel.cheese01 && channel.channelTotal >= 100_000) {
                                    channel.cheese01 = true;
                                    channel.cheeseDate01 = makeDate(year, month, dayData.day);
                                }
                                
                                if(!channel.cheese02 && channel.channelTotal >= 1_000_000) {
                                    channel.cheese02 = true;
                                    channel.cheeseDate02 = makeDate(year, month, dayData.day);
                                }
                                
                                if(!channel.cheese03 && channel.channelTotal >= 10_000_000) {
                                    channel.cheese03 = true;
                                    channel.cheeseDate03 = makeDate(year, month, dayData.day);
                                }
                                
                                if(!channel.cheese04 && channel.channelTotal >= 100_000_000) {
                                    channel.cheese04 = true;
                                    channel.cheeseDate04 = makeDate(year, month, dayData.day);
                                }

                                if(channel.onedayMaxCheese < dayData.dayTotal) {
                                    channel.onedayMaxCheese = dayData.dayTotal;
                                    channel.onedayMaxCheeseDate = makeDate(year, month, dayData.day);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

function createNewChannelData(channelData) {
    return {
        channelId: channelData.channelId,
        channelName: channelData.channelName,
        channelImageUrl: channelData.channelImageUrl,
        channelTotal: 0,
        channelCount: 0,
        cheese01: false,
        cheeseDate01: null,
        cheese02: false,
        cheeseDate02: null,
        cheese03: false,
        cheeseDate03: null,
        cheese04: false,
        cheeseDate04: null,
        firstCheeseDate: null,
        onedayMaxCheese: 0,
        onedayMaxCheeseDate: null,
        yearData: []
    }
}

function returnSelectboxIconArrow() {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10" fill="none" class="cch_selectbox_icon_arrow">
        <path fill="currentColor" fill-rule="evenodd" d="M.21 2.209a.715.715 0 0 1 1.01 0L5 5.983 8.78 2.21a.715.715 0 0 1 1.01 0 .712.712 0 0 1 0 1.008L5 8 .21 3.217a.712.712 0 0 1 0-1.008Z" clip-rule="evenodd"></path>
    </svg>`;
}

function closeCheeseHistoryModal() {
    document.getElementById("cheeseHistoryModal")?.remove();
    document.body.style.overflow = "";
}

initCheeseHistory();