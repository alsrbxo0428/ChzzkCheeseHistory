(async () => {
    if(window.location.hostname === "chzzk.naver.com" || window.location.hostname === "game.naver.com") {
        if(document.getElementById("cheeseHistoryModal")) return;
    
        if(!document.getElementById("cch-style")) {
            const link = document.createElement("link");
            link.id = "cch-style";
            link.rel = "stylesheet";
            link.href = chrome.runtime.getURL("css/chzzkCheeseHistory.css");
            document.head.appendChild(link);
        }
    
        const response = await fetch(
            chrome.runtime.getURL("cheeseHistory.html")
        );
    
        const html = await response.text();
        const modal = document.createElement("div");
        modal.id = "cheeseHistoryModal";
        modal.innerHTML = html;
        document.body.appendChild(modal);
    
        if(!document.getElementById("cch-chart-script")) {
            await new Promise((resolve) => {
                const script = document.createElement("script");
                script.id = "cch-chart-script";
                script.src = chrome.runtime.getURL("libs/chart.umd.js");
                script.onload = resolve;
                document.body.appendChild(script);
            });
        }
    
        const oldScript = document.getElementById("cch-main-script");
        if(oldScript) {
            oldScript.remove();
        }
    
        await new Promise((resolve) => {
            const script = document.createElement("script");
            script.id = "cch-main-script";
            script.src = chrome.runtime.getURL("js/cheeseHistory.js");
            script.onload = resolve;
            document.body.appendChild(script);
        });
    } else {
        alert("치지직, 네이버 게임 프로필 화면에서만 조회 가능합니다.");
        return;
    }
}) ();